# -*- coding: utf-8 -*-

from . import cli

if __name__ == '__main__':
    cli.main()
